whats-currently-playing
=================
A fun little widget to show what’s playing on iTunes or Spotify. If there are any more applications that you use, please feel free to extend mine or let me know what your app is and I’ll see what I can do. 

Thank you ThomasBrace for creating Spotify-Current-Track, you inspired me to add the iTunes stuff. 

I hope you enjoy.
